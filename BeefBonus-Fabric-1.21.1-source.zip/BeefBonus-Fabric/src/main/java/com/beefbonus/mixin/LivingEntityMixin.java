package com.beefbonus.mixin;

import com.beefbonus.BeefBonus;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "eatFood", at = @At("RETURN"))
    private void beefbonus$afterEating(World world, ItemStack stack, CallbackInfo ci) {
        if (world.isClient || !stack.isOf(Items.COOKED_BEEF)) return;
        if (!((Object) this instanceof ServerPlayerEntity player)) return;

        Random random = player.getRandom();
        int roll = random.nextInt(100);
        String[] rewards;
        int min, max;
        if (roll < 48) {
            rewards = new String[]{"iron_ingot", "coal", "copper_ingot", "redstone", "lapis_lazuli", "quartz", "glass", "stone", "oak_planks", "torch", "bread", "arrow", "string", "leather", "gold_nugget", "amethyst_shard"};
            min = 4; max = 24;
        } else if (roll < 78) {
            rewards = new String[]{"gold_ingot", "diamond", "emerald", "obsidian", "glowstone", "sea_lantern", "bookshelf", "experience_bottle", "ender_pearl", "golden_apple", "iron_block", "honey_block", "slime_block", "prismarine_shard", "firework_rocket"};
            min = 1; max = 8;
        } else if (roll < 95) {
            rewards = new String[]{"diamond_pickaxe", "diamond_sword", "diamond_chestplate", "diamond_helmet", "diamond_leggings", "diamond_boots", "bow", "crossbow", "shield", "anvil", "enchanted_book", "golden_carrot", "netherite_scrap"};
            min = 1; max = 2;
        } else {
            rewards = new String[]{"netherite_ingot", "totem_of_undying", "elytra", "beacon", "enchanted_golden_apple", "trident", "mace", "nether_star"};
            min = 1; max = 1;
        }

        String id = rewards[random.nextInt(rewards.length)];
        Item item = Registries.ITEM.get(Identifier.of("minecraft", id));
        if (item == Items.AIR) {
            BeefBonus.LOGGER.warn("Hadiah BeefBonus tidak ditemukan: {}", id);
            return;
        }
        int count = min + random.nextInt(max - min + 1);
        ItemStack reward = new ItemStack(item, Math.min(count, item.getMaxCount()));
        if (!player.getInventory().insertStack(reward)) player.dropItem(reward, false);
        player.sendMessage(Text.literal("§6[BeefBonus] §fKamu mendapat §e" + count + "x " + id.replace('_', ' ') + "§f!"), true);
    }
}
