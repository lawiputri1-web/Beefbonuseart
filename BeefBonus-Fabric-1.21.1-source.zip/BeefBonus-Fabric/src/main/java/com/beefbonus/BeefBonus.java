package com.beefbonus;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class BeefBonus implements ModInitializer {
    public static final String MOD_ID = "beefbonus";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("BeefBonus loaded! Makan Cooked Beef untuk hadiah acak.");
    }
}
